-- ОРБИТА 0.3: ограничение новых заказов без отмены принятой поездки.
-- Проверено с предоставленными служебными функциями orbita_private в PostgreSQL 17.
-- Заменяет ровно одну функцию; таблицы, политики и сохранённые заказы не меняет.
-- Перед применением открыть версию 0.3 у администратора и тестового водителя.
-- Повторный запуск допустим. Неизвестная редакция функции не перезаписывается.

BEGIN;
SET LOCAL lock_timeout = '5s';
SET LOCAL statement_timeout = '30s';

-- Keep the same transaction lock used by all existing order-changing RPCs.
DO $preflight$
DECLARE v_source text;
BEGIN
  PERFORM pg_catalog.pg_advisory_xact_lock(76421, 1);
  SELECT pg_catalog.md5(pg_catalog.replace(p.prosrc, pg_catalog.chr(13), ''))
    INTO v_source FROM pg_catalog.pg_proc p
    WHERE p.oid = pg_catalog.to_regprocedure('public.orbita_admin_approve_driver(uuid,boolean)');
  IF v_source IS NULL OR v_source NOT IN ('3aae49a41693c538b05826997682ae73', '99e4c4e7e7794fe25b3343529e6ca3c5') THEN
    RAISE EXCEPTION 'Функция изменилась после выгрузки. Исправление не применено; нужна новая выгрузка SQL.';
  END IF;
END;
$preflight$;

CREATE OR REPLACE FUNCTION public.orbita_admin_approve_driver(p_driver_id uuid, p_approved boolean)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO ''
AS $function$
-- ORBITA 0.3: access to new orders is separate from finishing an accepted trip.
begin
  if auth.uid() is null then raise exception 'Требуется вход'; end if;
  if orbita_private.is_admin() is distinct from true then
    raise exception 'Только администратор';
  end if;
  if p_approved is null then raise exception 'Укажите разрешение или ограничение доступа'; end if;
  perform pg_catalog.pg_advisory_xact_lock(76421, 1);
  perform d.user_id from public.orbita_drivers d
    where d.user_id=p_driver_id for update;
  if not found then raise exception 'Водитель не найден'; end if;

  if not p_approved then
    -- An unaccepted offer may be reassigned. Accepted rides are never touched.
    update public.orbita_offer_attempts set result='offline'
      where driver_id=p_driver_id and result='offered';
    update public.orbita_orders set status='new',driver_id=null,offered_until=null
      where driver_id=p_driver_id and status='offered';
  end if;

  update public.orbita_drivers set approved=p_approved,
    on_line=(case when p_approved then on_line else false end)
    where user_id=p_driver_id;
  perform orbita_private.dispatch_locked();
  return pg_catalog.jsonb_build_object('user_id',p_driver_id,'approved',p_approved);
end;
$function$;

COMMIT;

SELECT pg_catalog.md5(pg_catalog.replace(p.prosrc, pg_catalog.chr(13), '')) =
  '99e4c4e7e7794fe25b3343529e6ca3c5' AS driver_access_patch_installed
FROM pg_catalog.pg_proc p
WHERE p.oid = pg_catalog.to_regprocedure('public.orbita_admin_approve_driver(uuid,boolean)');
