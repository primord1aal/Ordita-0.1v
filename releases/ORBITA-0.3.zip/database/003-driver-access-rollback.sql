-- Возврат прежней функции. Не восстанавливает ранее отключённым водителям доступ.
-- Применять только при необходимости отката версии 0.3.

BEGIN;
SET LOCAL lock_timeout = '5s';
SET LOCAL statement_timeout = '30s';

-- Keep the same transaction lock used by all existing order-changing RPCs.
DO $preflight$
DECLARE v_source text;
BEGIN
  PERFORM pg_catalog.pg_advisory_xact_lock(76421, 1);
  SELECT pg_catalog.md5(pg_catalog.replace(p.prosrc, pg_catalog.chr(13), ''))
    INTO v_source FROM pg_catalog.pg_proc p
    WHERE p.oid = pg_catalog.to_regprocedure('public.orbita_admin_approve_driver(uuid,boolean)');
  IF v_source IS NULL OR v_source NOT IN ('3aae49a41693c538b05826997682ae73', '99e4c4e7e7794fe25b3343529e6ca3c5') THEN
    RAISE EXCEPTION 'Функция изменилась после выгрузки. Исправление не применено; нужна новая выгрузка SQL.';
  END IF;
END;
$preflight$;

CREATE OR REPLACE FUNCTION public.orbita_admin_approve_driver(p_driver_id uuid, p_approved boolean)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
begin
  if not orbita_private.is_admin() then raise exception 'Только администратор'; end if;
  perform pg_catalog.pg_advisory_xact_lock(76421, 1);
  if exists(select 1 from public.orbita_orders
    where driver_id=p_driver_id and status in ('accepted','arrived','on_trip')) then
    raise exception 'Нельзя отключить водителя во время поездки';
  end if;
  if not exists(select 1 from public.orbita_drivers where user_id=p_driver_id) then
    raise exception 'Водитель не найден';
  end if;
  if not p_approved then
    update public.orbita_offer_attempts set result='offline'
      where driver_id=p_driver_id and result='offered';
    update public.orbita_orders set status='new',driver_id=null,offered_until=null
      where driver_id=p_driver_id and status='offered';
  end if;
  update public.orbita_drivers set approved=p_approved,
    on_line=(case when p_approved then on_line else false end)
    where user_id=p_driver_id;
  perform orbita_private.dispatch_locked();
  return pg_catalog.jsonb_build_object('user_id',p_driver_id,'approved',p_approved);
end;
$function$;

COMMIT;
