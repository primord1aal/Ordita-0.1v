/* Passenger notifications consume authenticated order snapshots, never raw pushes. */
(() => {
  'use strict';
  const messages = Object.freeze({
    accepted: '🚕 Водитель принял ваш заказ и направляется к вам',
    arrived: '🚖 Ваш автомобиль прибыл! Можете выходить',
    on_trip: '🚕 Поездка началась',
    completed: '✅ Поездка завершена. Спасибо, что выбрали «Орбиту»!',
    cancelled: '⚠️ Ваш заказ отменён',
  });
  const active = new Set(['new', 'offered', 'accepted', 'arrived', 'on_trip']);
  const valid = new Set([...active, 'completed', 'cancelled']);
  const element = (tag, content, className = '') => {
    const node = document.createElement(tag);
    node.textContent = content;
    node.className = className;
    return node;
  };

  class PassengerEvents {
    constructor(options) {
      this.options = options;
      this.key = null;
      this.generation = 0;
      this.orders = [];
      this.memory = { version: 1, orders: {} };
      this.databasePromise = null;
      this.databaseAvailable = false;
      this.dialogOrderId = null;

      const controls = element('div', '', 'passenger-tools');
      controls.innerHTML = '<div class="driver-tools"><button type="button" class="btn secondary small" id="passengerSoundToggle" aria-pressed="false">Включить звук прибытия</button><button type="button" class="btn secondary small" id="passengerNotificationToggle" aria-pressed="false">Включить уведомления</button></div><p class="help" id="passengerSoundStatus" role="status">Для звукового сигнала включите звук. При создании заказа браузер также запросит запуск звука.</p><p class="help" id="passengerNotificationStatus">Статусы обновляются автоматически. Держите приложение открытым.</p>';
      options.root.querySelector('form').before(controls);
      document.getElementById('passengerSoundToggle').onclick = options.onToggleSound;
      document.getElementById('passengerNotificationToggle').onclick = options.onToggleNotifications;

      this.toast = element('aside', '', 'passenger-toast hidden');
      this.toast.id = 'passengerNotification';
      this.toast.setAttribute('role', 'status');
      this.toast.setAttribute('aria-live', 'polite');
      this.toastMessage = element('p', '');
      const dismiss = element('button', 'Понятно', 'btn secondary');
      dismiss.type = 'button';
      dismiss.onclick = () => this.toast.classList.add('hidden');
      this.toast.append(this.toastMessage, dismiss);

      this.dialog = element('dialog', '', 'passenger-arrival');
      this.dialog.id = 'passengerArrivalDialog';
      this.dialog.setAttribute('aria-labelledby', 'passengerArrivalHeading');
      this.dialog.setAttribute('aria-describedby', 'passengerArrivalMessage');
      this.dialog.innerHTML = '<div class="arrival-symbol" aria-hidden="true">🚖</div><div class="badge good" id="passengerArrivalBadge">АВТОМОБИЛЬ ПРИБЫЛ</div><h2 id="passengerArrivalHeading">Ваш автомобиль прибыл!</h2><p id="passengerArrivalMessage"></p><p class="mini" id="passengerArrivalOrder"></p><div class="arrival-car" id="passengerArrivalCar"></div><div class="arrival-footer"><button type="button" class="btn" id="passengerArrivalAcknowledge" autofocus>Понятно</button></div>';
      this.dialog.addEventListener('cancel', event => event.preventDefault());
      this.dialog.querySelector('button').onclick = () => this.acknowledge();
      document.body.append(this.toast, this.dialog);
      window.addEventListener('storage', event => {
        if (this.key && event.key === this.key) {
          try {
            const data = JSON.parse(event.newValue);
            if (data?.version === 1 && data.orders &&
                (data.revision || 0) >= (this.memory.revision || 0)) {
              this.memory = data; this.restore(data);
            }
          } catch (_) {}
        }
      });
    }

    begin(projectOrigin, userId) {
      this.stop();
      this.userId = String(userId);
      this.key = 'orbita-passenger-events-v1:' + encodeURIComponent(projectOrigin) + ':' + this.userId;
      this.memory = { version: 1, orders: {} };
    }

    stop() {
      this.generation += 1;
      this.key = null;
      this.userId = null;
      this.orders = [];
      this.dialogOrderId = null;
      this.displaySignature = null;
      if (this.dialog.open) this.dialog.close();
      this.toast.classList.add('hidden');
      this.toastMessage.textContent = '';
      document.getElementById('passengerArrivalCar').replaceChildren();
      document.getElementById('passengerArrivalOrder').textContent = '';
    }

    read() {
      for (const storageName of ['localStorage', 'sessionStorage']) {
        try {
          const data = JSON.parse(window[storageName].getItem(this.key) || 'null');
          if (data?.version === 1 && data.orders && typeof data.orders === 'object' &&
              (!this.memory.revision || (data.revision || 0) >= this.memory.revision)) {
            this.memory = data;
          }
        } catch (_) { /* Fall back to another store or this page's memory. */ }
      }
      return this.memory;
    }

    write(data) {
      if ((this.memory.revision || 0) > (data.revision || 0)) return;
      this.memory = data;
      for (const storageName of ['localStorage', 'sessionStorage']) {
        try { window[storageName].setItem(this.key, JSON.stringify(data)); return; }
        catch (_) { /* Some privacy settings disable persistent storage. */ }
      }
      if (!this.databaseAvailable) document.getElementById('passengerNotificationStatus').textContent =
        'Браузер не сохраняет подтверждения. После перезапуска сообщения могут появиться снова.';
    }

    database() {
      if (!this.databasePromise) this.databasePromise = new Promise(resolve => {
        if (!window.indexedDB) { resolve(null); return; }
        try {
          const request = indexedDB.open('orbita-passenger-events-v1', 1);
          request.onupgradeneeded = () => request.result.createObjectStore('ledgers');
          request.onsuccess = () => {
            this.databaseAvailable = true;
            request.result.onversionchange = () => request.result.close();
            resolve(request.result);
          };
          request.onerror = () => resolve(null);
          request.onblocked = () => resolve(null);
        } catch (_) { resolve(null); }
      });
      return this.databasePromise;
    }

    async exclusive(action) {
      const key = this.key, generation = this.generation;
      const current = () => key === this.key && generation === this.generation;
      const db = await this.database();
      if (!current()) return null;
      if (db) {
        try {
          return await new Promise((resolve, reject) => {
            const transaction = db.transaction('ledgers', 'readwrite');
            const store = transaction.objectStore('ledgers'), request = store.get(key);
            let data, result, cancelled = false;
            request.onsuccess = () => {
              if (!current()) { cancelled = true; transaction.abort(); return; }
              try {
                data = request.result || this.read();
                result = action(data);
                data.revision = (Number.isSafeInteger(data.revision) ? data.revision : 0) + 1;
                store.put(data, key);
              } catch (error) { transaction.abort(); reject(error); }
            };
            transaction.oncomplete = () => {
              if (current()) this.write(data);
              resolve(current() ? result : null);
            };
            transaction.onerror = () => reject(transaction.error);
            transaction.onabort = () => cancelled ? resolve(null) : reject(transaction.error);
          });
        } catch (_) { /* Restricted IndexedDB: retain the storage fallback. */ }
      }
      const run = () => {
        if (!current()) return null;
        const data = this.read(), result = action(data);
        data.revision = (Number.isSafeInteger(data.revision) ? data.revision : 0) + 1;
        this.write(data);
        return result;
      };
      if (navigator.locks?.request) return navigator.locks.request(key, run);
      return run();
    }

    async observe(orders) {
      if (!this.key) return;
      const generation = this.generation;
      const mine = orders.filter(order => String(order.passenger_id) === this.userId &&
        /^[1-9]\d*$/.test(String(order.id)) && valid.has(order.status));
      // The API is newest first; sorting by the monotonic numeric order ID also
      // makes the choice deterministic for snapshots without created_at.
      mine.sort((a, b) => {
        const left = BigInt(a.id), right = BigInt(b.id);
        return left < right ? 1 : left > right ? -1 : 0;
      });
      this.orders = mine;
      const result = await this.exclusive(data => {
        const changes = [];
        for (const order of mine.slice(0, 300)) {
          const id = String(order.id), previous = data.orders[id];
          const handled = new Set(Array.isArray(previous?.handled) ? previous.handled.filter(s => valid.has(s)) : []);
          const changed = previous?.status !== order.status;
          const isLatest = mine[0] === order;
          // Seed terminal history silently. A first-seen active order can still
          // require attention (including arrival on a newly opened device).
          const notify = isLatest && changed && !handled.has(order.status) &&
            !!messages[order.status] && (!!previous || active.has(order.status));
          handled.add(order.status);
          data.orders[id] = {
            status: order.status, handled: [...handled],
            pending: (previous?.pending === true || notify && order.status === 'arrived') && isLatest,
          };
          if (notify) changes.push({
            id: this.key + '|order:' + id + '|' + order.status,
            orderId: id, status: order.status, message: messages[order.status], order,
          });
        }
        const retained = Object.create(null);
        for (const order of mine.slice(0, 300)) retained[String(order.id)] = data.orders[String(order.id)];
        data.orders = retained;
        // The transaction commits before visible/audible/system side effects.
        return { data, changes };
      });
      if (!result || generation !== this.generation || !this.key) return;
      for (const event of result.changes) {
        if (event.status === 'arrived') {
          this.toast.classList.add('hidden');
          this.displayArrival(event.order);
          this.effect(this.options.onArrival);
        } else if (!result.data.orders[event.orderId]?.pending) {
          this.toast.dataset.eventId = event.id;
          this.toast.dataset.status = event.status;
          this.toastMessage.textContent = event.message;
          this.toast.classList.remove('hidden');
        }
        this.effect(this.options.onNotify, event);
      }
      this.restore(this.read());
    }

    effect(callback, value) {
      try { Promise.resolve(callback?.(value)).catch(() => {}); }
      catch (_) { /* Unsupported audio/vibration/notifications cannot hide arrival. */ }
    }

    restore(data) {
      if (!this.key) return;
      const order = this.orders[0];
      if (order && data.orders[String(order.id)]?.pending === true) {
        this.displayArrival(order);
      } else if (this.dialog.open) {
        this.dialog.close(); this.dialogOrderId = null;
      }
    }

    displayArrival(order) {
      const signature = JSON.stringify([order.id, order.status, order.driver_name,
        order.car_model, order.plate]);
      if (this.dialog.open && this.displaySignature === signature) return;
      this.displaySignature = signature;
      this.dialogOrderId = String(order.id);
      this.dialog.dataset.orderId = this.dialogOrderId;
      this.dialog.dataset.status = order.status;
      document.getElementById('passengerArrivalBadge').textContent = order.status === 'arrived' ?
        'АВТОМОБИЛЬ ПРИБЫЛ' : 'СТАТУС ЗАКАЗА ОБНОВИЛСЯ';
      document.getElementById('passengerArrivalHeading').textContent = order.status === 'arrived' ?
        'Ваш автомобиль прибыл!' : messages[order.status] || 'Статус заказа обновлён';
      document.getElementById('passengerArrivalMessage').textContent = messages[order.status] || '';
      document.getElementById('passengerArrivalOrder').textContent = 'Заказ №' + order.id;
      const car = document.getElementById('passengerArrivalCar');
      car.replaceChildren();
      for (const [label, value] of [['Водитель', order.driver_name],
        ['Автомобиль', order.car_model], ['Номер', order.plate]]) {
        if (value) {
          const row = element('p', '', 'arrival-car-row');
          row.append(element('span', label), element('strong', String(value)));
          car.append(row);
        }
      }
      car.classList.toggle('hidden', !car.children.length);
      if (!this.dialog.open) this.dialog.showModal();
    }

    async acknowledge() {
      const id = this.dialogOrderId;
      if (!id || !this.key) return;
      if (this.dialog.open) this.dialog.close();
      this.dialogOrderId = null;
      this.displaySignature = null;
      await this.exclusive(data => {
        if (data.orders[id]) data.orders[id].pending = false;
      });
      this.effect(this.options.onAcknowledge);
    }
  }
  window.OrbitaPassengerEvents = PassengerEvents;
})();
