-- ОРБИТА 0.4: необязательное ускорение обновлений через Supabase Realtime.
-- Резервный опрос работает без этого скрипта.
-- Не меняет таблицы, заказы, RLS-политики и права пользователей.
BEGIN;
SET LOCAL lock_timeout = '5s';
DO $realtime$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_publication WHERE pubname='supabase_realtime') THEN
    RAISE EXCEPTION 'Публикация supabase_realtime отсутствует. Автоматический опрос приложения продолжит работать; настройка Realtime требует проверки проекта.';
  END IF;
  IF pg_catalog.to_regclass('public.orbita_orders') IS NULL THEN
    RAISE EXCEPTION 'Таблица public.orbita_orders не найдена.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_catalog.pg_publication_tables
    WHERE pubname='supabase_realtime' AND schemaname='public' AND tablename='orbita_orders') THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.orbita_orders;
  END IF;
END;
$realtime$;
COMMIT;
SELECT EXISTS (SELECT 1 FROM pg_catalog.pg_publication_tables
  WHERE pubname='supabase_realtime' AND schemaname='public' AND tablename='orbita_orders')
  AS passenger_realtime_enabled;
